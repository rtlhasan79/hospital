﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Hospital
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            bool flag = true;
            int n1 = 0;
            Doctors doctors = new Doctors();
            Patients patients = new Patients();
            Console.WriteLine("Welcome To Hosptial App");
            Console.WriteLine("Powered By Sina:Hasan");
            while (flag)
            {

                switch (n1)
                {
                    case 0:
                        Console.WriteLine("**************************************");
                        Console.WriteLine("Please Choose Your Option");
                        Console.WriteLine("1 : Patients");
                        Console.WriteLine("2 : Doctors");
                        Console.WriteLine("3 : Data");
                        Console.WriteLine("4 : Exit");
                        n1 = Convert.ToInt32(Console.ReadLine());
                        //Console.WriteLine("Please Choose Your Option");
                        //Console.WriteLine("**************************************");
                        //Console.WriteLine("1 : Add Patient");
                        //Console.WriteLine("2 : Remove Patinet");
                        //Console.WriteLine("3 : View Patients");
                        //Console.WriteLine("4 : Back");
                        //Console.WriteLine("5 : Exit");
                        //int n2 = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 1:
                        //Patients patients = new Patients();
                        n1=patients.Manage();
                        break;
                    case 2:
                        //Doctors doctors = new Doctors();
                        flag = doctors.Manage();
                        if (doctors.a == 1)
                        {
                            n1 = 0;
                        }
                        break;
                    case 3:
                        //Doctors d = new Doctors();
                        //Patients p = new Patients();
                        Console.WriteLine($"Number Of Doctors Is : {doctors.doctors.Count}");
                        Console.WriteLine($"Number Of Patients Is : {patients.patients.Count}");
                        Console.WriteLine("Press Any Key To Continue Koskesh");
                        Console.ReadKey();
                        n1 = 0;
                        Console.WriteLine();
                        break;
                    case 4:
                        Console.WriteLine("Have A Good Day");
                        Console.WriteLine("**************************************");
                        flag = false;
                        break;

                }
            }

        }
    }
}
