﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Hospital
{
    public class Patients : Input
    {
        public List<Patients> patients;
        bool flag = true;
        string illness;
        int Return = 1;
        public Patients()
        {
            patients = new List<Patients>();
        }
        public int Manage()
        {
            while (flag)
            {
                Console.WriteLine("Please Choose Your Option");
                Console.WriteLine("**************************************");
                Console.WriteLine("1 : Add Patient");
                Console.WriteLine("2 : Remove Patinet");
                Console.WriteLine("3 : View Patients");
                Console.WriteLine("4 : Back");
                Console.WriteLine("5 : Exit");
                int input = Convert.ToInt32(Console.ReadLine());
                switch (input)
                {
                    case 1:
                        int n1 = 1;
                        while (n1 == 1)
                        {
                            Console.WriteLine("Please Enter ID");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Please Enter Name");
                            string name = Console.ReadLine();
                            Console.WriteLine("Please Enter Family Name");
                            string family = Console.ReadLine();
                            Console.WriteLine("Please Enter Age");
                            int age = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Please Enter Illness");
                            string illness = Console.ReadLine();
                            Patients p1 = new Patients();
                            p1.id = id;
                            p1.name = name;
                            p1.family = family;
                            p1.age = age;
                            p1.illness = illness;
                            Add(p1);
                            Console.WriteLine("A New Patient Has Been Added To The List Successfully");
                            Console.WriteLine("If You Want To Add More Press 1");
                            n1 = Convert.ToInt32(Console.ReadLine());
                        }
                        break;
                    case 2:
                        Show();
                        if (patients != null)
                        {
                            Console.WriteLine("**************************************");
                            Console.WriteLine("Please Enter The ID You Want To Remove");
                            Remove(Convert.ToInt32(Console.ReadLine()));
                            Console.WriteLine("Patient Killed Successfully");
                        }
                        else
                        {
                            Console.WriteLine("No Patients !");
                            Console.WriteLine("Press Any Key To Continue");
                            Console.ReadKey();
                        }
                        break;
                    case 3:
                        Show();
                        Console.WriteLine("Press Any Key To Continue");
                        Console.ReadKey();
                        break;
                    case 4:
                        flag = false;
                        Return = 0;
                        break;
                    case 5:
                        flag = false;
                        Return = 4;
                        break;
                }
            }
            return Return;
        }
        public void Add(Patients p)
        {
            patients.Add(p);
        }
        public void Show()
        {
            if (patients.Count > 0)
            {
                foreach (var item in patients)
                {
                    Console.WriteLine($"ID : {item.id}  Name :{item.name}   Family Name : {item.family}  Age : {item.age}  Description : {item.illness}");
                }
            }
            else
            {
                Console.WriteLine("No Patients !");
            }
        }
        public void Remove(int a)
        {
            foreach (var item in patients)
            {
                if (item.id == a)
                {
                    patients.Remove(item);
                    break;
                }
                else
                {
                    Console.WriteLine("ID Not Found");
                }
            }

        }
    }
}
