﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Hospital
{
    public class Doctors : Input
    {
        public string description;
        public bool opt = true;
        public int a;
        int b = 0;
        bool flag = true;
        public List<Doctors> doctors;
        public Doctors()
        {
            doctors = new List<Doctors>();
        }
        //insert 
        public int Insert()
        {
            Console.WriteLine("Please Enter ID");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please Enter Name");
            string name = Console.ReadLine();
            Console.WriteLine("Please Enter Family Name");
            string family = Console.ReadLine();
            Console.WriteLine("Please Enter Age");
            int age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please Enter Description");
            string description = Console.ReadLine();
            Doctors d1 = new Doctors();
            d1.description = description;
            d1.id = id;
            d1.name = name;
            d1.age = age;
            d1.family = family;
            doctors.Add(d1);
            Console.WriteLine("A New Doctor Has Been Added To The List Successfully");
            Console.WriteLine("If You Want To Add More Press 1");
            b = Convert.ToInt32(Console.ReadLine());
            return b;
        }
        //add

        public void Show()
        {
            foreach (var item in doctors)
            {
                Console.WriteLine($"ID : {item.id}  Name :{item.name}   Family Name : {item.family}  Age : {item.age}  Description : {item.description}");
            }
        }
        public void Remove(int id)
        {
            foreach (var item in doctors)
            {
                if (item.id == id)
                {
                    doctors.Remove(item);
                    break;
                }
            }


            //var doc = doctors.Where(d => d.id == id).FirstOrDefault();
            //if (doc != null)
            //{
            //    doctors.Remove(doc);
            //}
            //else
            //{
            //    Console.WriteLine("Not Found");
            //}
        }
        public bool Manage()
        {
            while (opt)
            {

                Console.WriteLine("Please Choose Your Option");
                Console.WriteLine("**************************************");
                Console.WriteLine("1 : Add Doctor");
                Console.WriteLine("2 : Remove Doctor");
                Console.WriteLine("3 : View Doctors");
                Console.WriteLine("4 : Back");
                Console.WriteLine("5 : Exit");
                int n1 = Convert.ToInt32(Console.ReadLine());
                switch (n1)
                {
                    case 1:
                        b = Insert();
                        while (b == 1)
                        {
                            b = Insert();
                        }
                        break;
                    case 2:
                        while (true)
                        {
                            if (doctors.Count != 0)
                            {
                                Show();
                                Console.WriteLine("Please Enter The ID You Want To Remove");
                                Remove(Convert.ToInt32(Console.ReadLine()));
                                Console.WriteLine("Target Has Been Nuetralized");
                                if (doctors.Count != 0)
                                {
                                    Console.WriteLine("If You Want To Remove More Press 1");
                                    int input = Convert.ToInt32(Console.ReadLine());

                                    if (input != 1)
                                    {
                                        break;
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine("No Doctors Here");
                                Console.WriteLine("Consider Some New Payments");
                                Console.WriteLine("Press Any Key To Continue");
                                Console.ReadKey();
                                break;
                            }
                        }
                        break;
                    case 3:
                        if (doctors.Count != 0)
                        {
                            Show();
                            Console.WriteLine("Press Any Key To Continue");
                            Console.ReadKey();
                            opt = false;
                            a = 1;
                        }
                        else
                            Console.WriteLine("No Doctors !");
                        break;
                    case 4:
                        opt = false;
                        a = 1;
                        break;
                    case 5:
                        flag = false;
                        opt = false;
                        Console.WriteLine("Have A Good Day");
                        Console.WriteLine("**************************************");
                        break;
                }
            }
            return flag;
        }
    }
}



